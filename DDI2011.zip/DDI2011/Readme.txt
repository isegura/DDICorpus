The gold annotations for test files are in gold annotations.txt. Each row in this file represents a pair of drugs. 
If the pair is a DDI then the pair is annotated with 1, eoc 0.
